Ronald’s Mac Label Helper — first Mac test release

1. This first version needs Python 3.10 or later. If needed, install it from:
   https://www.python.org/downloads/macos/
2. Keep this folder together and double-click Start-Mac-Label-Helper.command.
   It opens Terminal, creates a local environment and installs Bluetooth support
   on its first run. Keep the Terminal window open while printing.
   If macOS asks how to open the downloaded launcher, use Finder’s Open action.
3. Disconnect the M110 from your iPhone, Print Master and Phomymo.
4. In Mac Safari, open a Glazy recipe and launch Ronald’s Glaze Label Printer.
5. Click Connect M110. Safari opens the local helper tab. Allow the popup if asked.
6. Click Find printers, choose your M110 and connect. If macOS asks for Bluetooth
   permission, allow it. Return to the Glazy tab and print one compact label.
7. Keep the helper tab and Terminal window open. Stop the helper with Control-C
   in its Terminal window when finished. Your chosen printer stays saved locally.

If Bluetooth permission was denied, use System Settings → Privacy & Security →
Bluetooth and allow the application macOS listed for this Terminal/Python run.
The Mac helper uses native CoreBluetooth through Bleak; beacio is not needed.

All communication stays on 127.0.0.1. This helper listens only on your own Mac.
No certificate, cloud server, account or network printer service is needed.
The local helper tab accepts label jobs only from its Glazy opener and uses a
fresh process token for local API requests. Label pixels are not saved to disk.
This helper has been tested with a simulated printer; the physical Mac-to-M110
connection still requires your first test. No automatic retries after uncertain
transmission errors. Power-cycle the M110 before retrying an interrupted raster.

Source is in Ronald’s private glazy-tools repository. Distributed runtime code
is compacted/packed; this is packaging rather than a secrecy guarantee.
Python, Bleak and aiohttp are installed separately and retain their own licences.
