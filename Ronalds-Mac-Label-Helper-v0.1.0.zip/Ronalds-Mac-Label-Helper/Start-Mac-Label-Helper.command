#!/bin/bash
set -euo pipefail
RB_HELPER_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$RB_HELPER_DIR"
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'This launcher is for macOS.'
  exit 1
fi
RB_PYTHON=''
for RB_CANDIDATE in python3 python3.14 python3.13 python3.12 python3.11 python3.10 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if command -v "$RB_CANDIDATE" >/dev/null 2>&1 && "$RB_CANDIDATE" -c 'import sys; raise SystemExit(sys.version_info < (3, 10))' 2>/dev/null; then
    RB_PYTHON="$(command -v "$RB_CANDIDATE")"
    break
  fi
done
if [[ -z "$RB_PYTHON" ]]; then
  echo 'Python 3.10 or later is needed for this first Mac helper.'
  echo 'Install Python from https://www.python.org/downloads/macos/ then open this file again.'
  read -r -p 'Press Return to close…' RB_DONE
  exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
  "$RB_PYTHON" -m venv .venv
fi
if [[ ! -f .venv/rb-helper-dependencies-v1 ]]; then
  echo 'Setting up Bluetooth support. This is only needed on the first run…'
  .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
  touch .venv/rb-helper-dependencies-v1
fi
echo 'Leave this window open while printing from Safari.'
exec .venv/bin/python helper.py
